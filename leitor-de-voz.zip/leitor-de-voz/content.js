// Script injetado na aba quando a leitura começa.
// Extrai o texto "legível", divide em frases, destaca a frase atual e permite Alt+clique para ler dali.
(() => {
  try { if (window.__ttsReaderCleanup) window.__ttsReaderCleanup(); } catch (e) { /* contexto antigo */ }

  const MAX_CHUNK = 240; // frases maiores são quebradas (vozes online falham com textos longos)
  const HL_NAME = 'tts-reader-hl';

  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'CANVAS', 'IFRAME', 'OBJECT',
    'EMBED', 'VIDEO', 'AUDIO', 'SELECT', 'OPTION', 'TEXTAREA', 'INPUT', 'BUTTON', 'HEAD', 'MATH']);
  const NOISE = new Set(['NAV', 'ASIDE', 'FOOTER', 'DIALOG', 'PRE']);
  const NOISE_ROLES = new Set(['navigation', 'complementary', 'contentinfo', 'search', 'banner', 'dialog', 'alertdialog']);
  const NOISE_RE = /(?:^|[\s_-])(?:nav|navbar|menu|sidebar|footer|cookie|cookies|consent|advert|advertisement|ads?|promo|share|sharing|social|related|breadcrumbs?|newsletter|subscribe|popup|modal|toolbar)(?:$|[\s_-])/i;

  let data = { text: '', parts: [], segs: [] };

  // ---------- Extração ----------
  function ownExcluded(el, strict) {
    const tag = el.localName.toUpperCase();
    if (SKIP.has(tag)) return true;
    if (el.hidden || el.inert || el.getAttribute('aria-hidden') === 'true') return true;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') return true;
    if (!strict) return false;
    if (NOISE.has(tag)) return true;
    const inMain = () => !!el.closest('article, main, [role="main"]');
    if (tag === 'HEADER' && !inMain()) return true;
    const role = el.getAttribute('role');
    if (role && NOISE_ROLES.has(role) && !(role === 'banner' && inMain())) return true;
    const idc = (el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '');
    if (idc.trim() && NOISE_RE.test(idc)) return true;
    return false;
  }

  const blockCache = new WeakMap();
  function blockOf(el) {
    let cur = el;
    while (cur && cur.parentElement) {
      const c = blockCache.get(cur);
      if (c) return c;
      const d = getComputedStyle(cur).display;
      if (!(d.startsWith('inline') || d === 'contents')) {
        blockCache.set(el, cur);
        return cur;
      }
      cur = cur.parentElement;
    }
    return cur || document.body;
  }

  // Percorre os nós de texto, concatena em `text` (parágrafos separados por \n)
  // e guarda o mapa texto->nó em `parts` (para criar Ranges e destacar depois).
  function build(root, range, strict) {
    const parts = [];
    let text = '';
    let lastBlock = null;
    let pendingBreak = false;
    if (root.nodeType === 1 && ownExcluded(root, false)) return { text, parts };

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (n.nodeType === 1) {
          if (n.localName === 'br') return NodeFilter.FILTER_ACCEPT;
          return ownExcluded(n, strict) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    let n;
    while ((n = walker.nextNode())) {
      if (n.nodeType === 1) { pendingBreak = true; continue; } // <br>
      let s = 0;
      let e = n.nodeValue.length;
      if (range) {
        if (!range.intersectsNode(n)) continue;
        if (n === range.startContainer) s = range.startOffset;
        if (n === range.endContainer) e = range.endOffset;
        if (e <= s) continue;
      }
      const raw = n.nodeValue.slice(s, e).replace(/\s/g, ' '); // mantém o comprimento
      if (!/\S/.test(raw)) {
        if (text && !text.endsWith(' ') && !text.endsWith('\n')) text += ' ';
        continue;
      }
      const parent = n.parentElement;
      if (!parent) continue;
      const block = blockOf(parent);
      if (text && (pendingBreak || (lastBlock && block !== lastBlock)) && !text.endsWith('\n')) text += '\n';
      pendingBreak = false;
      lastBlock = block;
      parts.push({ node: n, start: text.length, len: raw.length, nodeStart: s });
      text += raw;
    }
    return { text, parts };
  }

  function pickRoot() {
    const body = document.body;
    const cands = [...document.querySelectorAll('article, main, [role="main"]')];
    let best = null;
    let bestLen = 0;
    for (const el of cands) {
      const l = (el.innerText || '').length;
      if (l > bestLen) { best = el; bestLen = l; }
    }
    const bodyLen = (body.innerText || '').length || 1;
    if (best && bestLen > 400 && bestLen >= bodyLen * 0.4) return best;
    return body;
  }

  // ---------- Frases ----------
  function splitLong(t, base) {
    const res = [];
    let pos = 0;
    while (pos < t.length) {
      let end = Math.min(pos + MAX_CHUNK, t.length);
      if (end < t.length) {
        const win = t.slice(pos, end);
        let cut = -1;
        const re = /[,;:–—]\s/g;
        let m;
        while ((m = re.exec(win))) if (m.index > MAX_CHUNK * 0.4) cut = m.index + 1;
        if (cut < 0) {
          const sp = win.lastIndexOf(' ');
          cut = sp > MAX_CHUNK * 0.4 ? sp : win.length;
        }
        end = pos + cut;
      }
      const piece = t.slice(pos, end);
      const lead = piece.length - piece.trimStart().length;
      const tr = piece.trim();
      if (tr) res.push({ start: base + pos + lead, end: base + pos + lead + tr.length });
      pos = end;
    }
    return res;
  }

  function segmentize(text, lang) {
    let seg = null;
    if (typeof Intl.Segmenter === 'function') {
      try { seg = new Intl.Segmenter(lang || undefined, { granularity: 'sentence' }); }
      catch (e) { seg = new Intl.Segmenter('en', { granularity: 'sentence' }); }
    }
    const out = [];
    let offset = 0;
    for (const para of text.split('\n')) {
      let first = true;
      let sentences;
      if (seg) {
        sentences = [...seg.segment(para)].map((x) => ({ s: x.index, t: x.segment }));
      } else {
        sentences = [...para.matchAll(/[^.!?…]+[.!?…]*\s*/g)].map((m) => ({ s: m.index, t: m[0] }));
      }
      for (const { s, t } of sentences) {
        const lead = t.length - t.trimStart().length;
        const trimmed = t.trim();
        if (!/[\p{L}\p{N}]/u.test(trimmed)) continue;
        for (const piece of splitLong(trimmed, offset + s + lead)) {
          out.push({ start: piece.start, end: piece.end, p: first });
          first = false;
        }
      }
      offset += para.length + 1;
    }
    return out;
  }

  // ---------- Mapa texto <-> DOM ----------
  function locateStart(off) {
    const parts = data.parts;
    if (!parts.length) return null;
    let lo = 0, hi = parts.length - 1, idx = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (parts[mid].start <= off) { idx = mid; lo = mid + 1; } else hi = mid - 1;
    }
    let p = parts[idx];
    if (off >= p.start + p.len && parts[idx + 1]) { p = parts[idx + 1]; return { node: p.node, off: p.nodeStart }; }
    return { node: p.node, off: p.nodeStart + Math.max(0, Math.min(off - p.start, p.len)) };
  }

  function locateEnd(off) {
    const parts = data.parts;
    if (!parts.length) return null;
    let lo = 0, hi = parts.length - 1, idx = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (parts[mid].start < off) { idx = mid; lo = mid + 1; } else hi = mid - 1;
    }
    const p = parts[idx];
    return { node: p.node, off: p.nodeStart + Math.max(0, Math.min(off - p.start, p.len)) };
  }

  function rangeFor(i) {
    const sg = data.segs[i];
    if (!sg) return null;
    const a = locateStart(sg.start);
    const b = locateEnd(sg.end);
    if (!a || !b) return null;
    try {
      const r = document.createRange();
      r.setStart(a.node, a.off);
      r.setEnd(b.node, b.off);
      return r;
    } catch (e) {
      return null;
    }
  }

  function segIndexAt(node, offset) {
    const part = data.parts.find((p) => p.node === node);
    if (!part) return -1;
    const abs = part.start + Math.max(0, Math.min(offset - part.nodeStart, part.len));
    const segs = data.segs;
    for (let i = 0; i < segs.length; i++) {
      if (abs < segs[i].end) return i;
    }
    return segs.length ? segs.length - 1 : -1;
  }

  // ---------- Destaque e rolagem ----------
  function clearHighlight() {
    try { if (CSS.highlights) CSS.highlights.delete(HL_NAME); } catch (e) { /* ignora */ }
  }

  function scrollParent(el) {
    for (let cur = el; cur && cur !== document.body && cur !== document.documentElement; cur = cur.parentElement) {
      const oy = getComputedStyle(cur).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && cur.scrollHeight > cur.clientHeight + 4) return cur;
    }
    return document.scrollingElement || document.documentElement;
  }

  function highlight(i, scroll) {
    const r = rangeFor(i);
    if (!r) { clearHighlight(); return; }
    try { if (CSS.highlights) CSS.highlights.set(HL_NAME, new Highlight(r)); } catch (e) { /* ignora */ }
    if (!scroll) return;
    const rc = r.getBoundingClientRect();
    const sp = scrollParent(r.startContainer.parentElement);
    const isDoc = sp === document.scrollingElement || sp === document.documentElement;
    const top = isDoc ? 0 : sp.getBoundingClientRect().top;
    const h = isDoc ? window.innerHeight : sp.clientHeight;
    if (rc.top < top + h * 0.12 || rc.bottom > top + h * 0.85) {
      sp.scrollBy({ top: rc.top - (top + h * 0.3), behavior: 'smooth' });
    }
  }

  // ---------- API de mensagens ----------
  function extract(mode) {
    clearHighlight();
    const sel = window.getSelection();
    const selStr = (sel ? sel.toString() : '').trim();
    const use = mode === 'auto' ? (selStr ? 'selection' : 'page') : (mode === 'selection' ? 'selection' : 'page');
    const lang = document.documentElement.lang || '';
    let built = { text: '', parts: [] };

    if (use === 'selection') {
      if (!selStr) return { error: 'no-selection' };
      if (sel.rangeCount) {
        const range = sel.getRangeAt(0);
        let root = range.commonAncestorContainer;
        if (root.nodeType !== 1) root = root.parentElement;
        if (root) built = build(root, range, false);
      }
      if (!built.text.trim()) {
        // seleção dentro de <input>/<textarea>: sem destaque possível
        built = { text: selStr.replace(/[ \t ]+/g, ' '), parts: [] };
      }
    } else {
      built = build(pickRoot(), null, true);
      if (built.text.replace(/\s/g, '').length < 150) built = build(document.body, null, false);
    }

    data = { text: built.text, parts: built.parts, segs: [] };
    data.segs = segmentize(data.text, lang);

    let startIndex = 0;
    if (mode === 'fromView' && use === 'page') {
      for (let i = 0; i < data.segs.length; i++) {
        const r = rangeFor(i);
        if (!r) continue;
        const rc = r.getBoundingClientRect();
        if (rc.height > 0 && rc.top >= 0 && rc.top < window.innerHeight) { startIndex = i; break; }
      }
    }

    return {
      mode: use,
      title: document.title || '',
      lang,
      startIndex,
      segments: data.segs.map((s) => ({ t: data.text.slice(s.start, s.end).replace(/\s+/g, ' '), p: s.p }))
    };
  }

  function onMsg(msg, _sender, sendResponse) {
    if (!msg || !msg.type) return;
    if (msg.type === 'extract') sendResponse(extract(msg.mode));
    else if (msg.type === 'highlight') { highlight(msg.index, !!msg.scroll); sendResponse(true); }
    else if (msg.type === 'clear') { clearHighlight(); sendResponse(true); }
  }

  // Alt+clique (Option+clique no Mac) em um trecho: continua a leitura a partir dali.
  function onClick(e) {
    if (!e.altKey || !data.segs.length || !data.parts.length) return;
    const caret = document.caretRangeFromPoint ? document.caretRangeFromPoint(e.clientX, e.clientY) : null;
    if (!caret) return;
    const idx = segIndexAt(caret.startContainer, caret.startOffset);
    if (idx < 0) return;
    e.preventDefault();
    e.stopPropagation();
    try { chrome.runtime.sendMessage({ type: 'seekFromPage', index: idx }); } catch (err) { /* ignora */ }
  }

  chrome.runtime.onMessage.addListener(onMsg);
  document.addEventListener('click', onClick, true);

  window.__ttsReaderCleanup = () => {
    chrome.runtime.onMessage.removeListener(onMsg);
    document.removeEventListener('click', onClick, true);
    clearHighlight();
  };
})();
