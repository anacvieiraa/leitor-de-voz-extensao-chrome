// Código compartilhado entre o service worker (background.js) e o popup.

export const DEFAULTS = {
  rate: 1,            // velocidade (0.5 – 3)
  pitch: 1,           // tom (0.5 – 2)
  volume: 1,          // volume (0 – 1)
  locale: 'auto',     // 'auto' = idioma da página | 'pt-BR' | 'en-GB' | ...
  voices: {},         // { 'pt-BR': 'Nome da voz' } – voz preferida por país/idioma
  highlight: true,    // destacar a frase lida na página
  autoscroll: true,   // rolar a página acompanhando a leitura
  clean: true,        // ignorar links, [1], emojis…
  replacements: ''    // dicionário de pronúncia: "palavra=como falar" (uma por linha)
};

export const SAMPLES = {
  pt: 'Olá! Esta é a voz selecionada para a leitura.',
  en: 'Hello! This is the selected voice for reading.',
  es: '¡Hola! Esta es la voz seleccionada para la lectura.',
  fr: 'Bonjour ! Voici la voix sélectionnée pour la lecture.',
  de: 'Hallo! Das ist die ausgewählte Stimme zum Vorlesen.',
  it: 'Ciao! Questa è la voce selezionata per la lettura.',
  nl: 'Hallo! Dit is de geselecteerde stem om voor te lezen.',
  pl: 'Cześć! To jest wybrany głos do czytania.',
  ru: 'Здравствуйте! Это выбранный голос для чтения.',
  tr: 'Merhaba! Bu, okuma için seçilen sestir.',
  ja: 'こんにちは。これは選択された読み上げ音声です。',
  zh: '你好！这是所选的朗读语音。',
  ko: '안녕하세요! 선택한 읽기 음성입니다.',
  ar: 'مرحبًا! هذا هو الصوت المحدد للقراءة.',
  hi: 'नमस्ते! यह पढ़ने के लिए चुनी गई आवाज़ है।'
};

export async function loadSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

export function getVoices() {
  return new Promise((resolve) => {
    try {
      chrome.tts.getVoices((v) => resolve(v || []));
    } catch (e) {
      resolve([]);
    }
  });
}

// "pt_br" / "PT-br" / "zh-Hans-CN" -> "pt-BR" / "pt-BR" / "zh-CN"
export function normLocale(l = '') {
  const parts = String(l).replace(/_/g, '-').split('-').filter(Boolean);
  if (!parts.length) return '';
  const lang = parts[0].toLowerCase();
  const region = parts.slice(1).find((p) => /^[A-Za-z]{2}$/.test(p));
  return region ? `${lang}-${region.toUpperCase()}` : lang;
}

export function baseLang(l = '') {
  return normLocale(l).split('-')[0];
}

export function voiceScore(v) {
  let s = 0;
  if (/natural|neural|premium|enhanced|wavenet/i.test(v.voiceName)) s += 3;
  if (/google/i.test(v.voiceName)) s += 2;
  if (v.remote) s += 1;
  return s;
}

export function voicesForLocale(voices, locale) {
  if (!locale) return [];
  let list = voices.filter((v) => normLocale(v.lang) === locale);
  if (!list.length) {
    const b = baseLang(locale);
    list = voices.filter((v) => baseLang(v.lang) === b);
  }
  return list;
}

// Escolhe a voz: a salva pelo usuário para este país/idioma, senão a "melhor" disponível.
export function pickVoice(voices, locale, saved = {}) {
  if (!locale) return null;
  const want = saved[locale];
  if (want) {
    const v = voices.find((x) => x.voiceName === want);
    if (v) return v;
  }
  const list = voicesForLocale(voices, locale).sort((a, b) => voiceScore(b) - voiceScore(a));
  return list[0] || null;
}

// Dado só o idioma ("pt"), escolhe o país mais adequado entre as vozes instaladas.
export function bestLocaleForBase(base, voices, browserLocale = navigator.language) {
  const locs = [...new Set(voices.map((v) => normLocale(v.lang)).filter((l) => baseLang(l) === base))];
  if (!locs.length) return base;
  const bl = normLocale(browserLocale);
  if (locs.includes(bl)) return bl;
  const best = (loc) => Math.max(...voices.filter((v) => normLocale(v.lang) === loc).map(voiceScore));
  locs.sort((a, b) => best(b) - best(a));
  return locs[0];
}

// Detecta o idioma/país do texto (chrome.i18n.detectLanguage funciona offline).
export async function detectLocale(sample, hintLang, voices) {
  let base = '';
  try {
    const r = await new Promise((res) => chrome.i18n.detectLanguage(sample || '', res));
    const top = r && r.languages && r.languages[0];
    if (top && top.language && top.language !== 'und') base = baseLang(top.language);
  } catch (e) { /* ignora */ }
  const hint = normLocale(hintLang || '');
  const hintBase = baseLang(hint);
  if (!base) base = hintBase || baseLang(navigator.language);
  if (hint.includes('-') && hintBase === base) return hint;
  return bestLocaleForBase(base, voices);
}

const dnLang = new Intl.DisplayNames(['pt-BR'], { type: 'language' });
const dnRegion = new Intl.DisplayNames(['pt-BR'], { type: 'region' });
const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);

export function localeLabel(loc) {
  const [l, r] = loc.split('-');
  let ln = l;
  try { ln = cap(dnLang.of(l) || l); } catch (e) { /* ignora */ }
  if (!r) return ln;
  let rn = r;
  try { rn = dnRegion.of(r) || r; } catch (e) { /* ignora */ }
  return `${ln} — ${rn}`;
}
