import {
  DEFAULTS, loadSettings, getVoices, normLocale, baseLang, voicesForLocale,
  detectLocale, localeLabel
} from './common.js';

const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg).catch(() => null);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmt1 = (n) => n.toFixed(1).replace('.', ',');

let settings = { ...DEFAULTS };
let voices = [];
let state = { status: 'idle', index: 0, total: 0 };
let detectedLocale = null;
let activeTab = null;
let dragging = false;
let saveTimer = null;

// ---------- Utilidades ----------
function save(immediate = false) {
  clearTimeout(saveTimer);
  const run = () => chrome.storage.sync.set(settings);
  if (immediate) run(); else saveTimer = setTimeout(run, 250);
}

async function loadVoices() {
  for (let i = 0; i < 6; i++) {
    const v = await getVoices();
    if (v.length) return v;
    await sleep(400);
  }
  return [];
}

async function detectActiveLocale() {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: () => ({ lang: document.documentElement.lang, text: ((document.body && document.body.innerText) || '').slice(0, 1500) })
    });
    return await detectLocale(result.text, result.lang, voices);
  } catch (e) {
    return null; // página protegida
  }
}

function effectiveLocale() {
  if (settings.locale !== 'auto') return settings.locale;
  return (state.status !== 'idle' && state.locale) || detectedLocale || normLocale(navigator.language);
}

function fmtTime(sec) {
  if (sec < 60) return `${Math.max(sec, 1)} s`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m} min`;
  return `${Math.floor(m / 60)} h ${m % 60} min`;
}

// ---------- Render: idioma/voz ----------
function renderLocales() {
  const sel = $('locale');
  const locs = [...new Set(voices.map((v) => normLocale(v.lang)).filter(Boolean))];
  const mine = baseLang(navigator.language);
  locs.sort((a, b) => {
    const pa = baseLang(a) === mine ? 0 : 1;
    const pb = baseLang(b) === mine ? 0 : 1;
    return pa - pb || localeLabel(a).localeCompare(localeLabel(b), 'pt-BR');
  });
  sel.replaceChildren(new Option('Automático (idioma da página)', 'auto'));
  for (const l of locs) sel.append(new Option(localeLabel(l), l));
  if (settings.locale !== 'auto' && !locs.includes(settings.locale)) sel.append(new Option(localeLabel(settings.locale) + ' (sem voz)', settings.locale));
  sel.value = settings.locale;

  const hint = $('detected');
  if (settings.locale === 'auto') {
    const loc = effectiveLocale();
    hint.textContent = `Detectado nesta página: ${localeLabel(loc)}`;
    hint.hidden = false;
  } else {
    hint.hidden = true;
  }
}

function renderVoices() {
  const sel = $('voice');
  const loc = effectiveLocale();
  const list = voicesForLocale(voices, loc);
  sel.replaceChildren(new Option(list.length ? 'Automática (melhor disponível)' : 'Padrão do sistema', ''));
  for (const v of list) {
    sel.append(new Option(`${v.voiceName}${v.remote ? ' · online' : ''}`, v.voiceName));
  }
  const saved = settings.voices[loc];
  sel.value = saved && list.some((v) => v.voiceName === saved) ? saved : '';
  $('novoice').hidden = voices.length > 0;
}

// ---------- Render: estado ----------
function renderState() {
  const st = state;
  const pill = $('pill');
  const labels = { idle: 'Pronto', loading: 'Carregando…', playing: 'Lendo', paused: 'Pausado' };
  pill.textContent = labels[st.status] || 'Pronto';
  pill.className = `pill ${st.status}`;

  $('title').textContent = st.title || (st.status === 'idle' ? 'Abra uma página e aperte ▶ para ouvir.' : '…');

  const active = st.status === 'playing' || st.status === 'paused';
  const seek = $('seek');
  seek.disabled = !active || !st.total;
  seek.max = Math.max(st.total - 1, 0);
  if (!dragging) seek.value = st.index || 0;
  $('pos').textContent = active && st.total ? `Trecho ${st.index + 1} de ${st.total}` : '—';
  $('eta').textContent = active && st.total ? `≈ ${fmtTime(st.remainingSec)} restantes` : '—';

  $('icoPlay').hidden = st.status === 'playing';
  $('icoPause').hidden = st.status !== 'playing';
  $('prev').disabled = !active;
  $('next').disabled = !active;
  $('stop').disabled = st.status === 'idle';
  $('play').disabled = st.status === 'loading';
  document.querySelectorAll('.modes button').forEach((b) => { b.disabled = st.status === 'loading'; });

  const err = $('err');
  err.hidden = !st.error;
  err.textContent = st.error || '';

  const note = $('sleepNote');
  if (st.sleepAt && st.sleepAt > Date.now()) {
    note.textContent = `A leitura vai parar às ${new Date(st.sleepAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.`;
    note.hidden = false;
  } else {
    note.hidden = true;
  }
}

function renderControls() {
  $('rate').value = settings.rate;
  $('pitch').value = settings.pitch;
  $('volume').value = settings.volume;
  updateOutputs();
  for (const k of ['highlight', 'autoscroll', 'clean']) $(k).checked = !!settings[k];
  $('replacements').value = settings.replacements;
}

function updateOutputs() {
  $('rateOut').textContent = `${fmt1(+settings.rate)}×`;
  $('pitchOut').textContent = fmt1(+settings.pitch);
  $('volumeOut').textContent = `${Math.round(settings.volume * 100)}%`;
  document.querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', Math.abs(+c.dataset.v - settings.rate) < 0.01));
}

function buildStatic() {
  const chips = $('chips');
  for (const v of [0.75, 1, 1.25, 1.5, 1.75, 2, 2.5]) {
    const b = document.createElement('button');
    b.className = 'chip';
    b.dataset.v = v;
    b.textContent = `${String(v).replace('.', ',')}×`;
    b.addEventListener('click', () => {
      settings.rate = v;
      $('rate').value = v;
      updateOutputs();
      save(true);
    });
    chips.append(b);
  }
  const sleepSel = $('sleep');
  for (const m of [0, 5, 10, 15, 30, 45, 60, 90]) sleepSel.append(new Option(m ? `${m} min` : 'Desligado', String(m)));
}

// ---------- Eventos ----------
function bind() {
  $('play').addEventListener('click', async () => {
    if (state.status === 'playing') state = (await send({ type: 'pause' })) || state;
    else if (state.status === 'paused') state = (await send({ type: 'resume' })) || state;
    else state = (await send({ type: 'play', tabId: activeTab.id, mode: 'auto' })) || state;
    renderState();
  });
  $('stop').addEventListener('click', async () => { state = (await send({ type: 'stop' })) || state; renderState(); });
  $('next').addEventListener('click', () => send({ type: 'next' }));
  $('prev').addEventListener('click', () => send({ type: 'prev' }));
  document.querySelectorAll('.modes button').forEach((b) => {
    b.addEventListener('click', async () => {
      state = (await send({ type: 'play', tabId: activeTab.id, mode: b.dataset.mode })) || state;
      renderState();
    });
  });

  const seek = $('seek');
  seek.addEventListener('pointerdown', () => { dragging = true; });
  seek.addEventListener('input', () => { $('pos').textContent = `Trecho ${+seek.value + 1} de ${state.total}`; });
  seek.addEventListener('change', async () => { dragging = false; await send({ type: 'seek', index: +seek.value }); });

  $('locale').addEventListener('change', (e) => {
    settings.locale = e.target.value;
    save(true);
    renderLocales();
    renderVoices();
  });
  $('voice').addEventListener('change', (e) => {
    const loc = effectiveLocale();
    const voicesMap = { ...settings.voices };
    if (e.target.value) voicesMap[loc] = e.target.value; else delete voicesMap[loc];
    settings.voices = voicesMap;
    save(true);
    if (state.status === 'idle') send({ type: 'preview', locale: loc });
  });
  $('test').addEventListener('click', (ev) => {
    ev.preventDefault();
    send({ type: 'preview', locale: effectiveLocale() });
  });

  for (const k of ['rate', 'pitch', 'volume']) {
    $(k).addEventListener('input', (e) => {
      settings[k] = +e.target.value;
      updateOutputs();
      save();
    });
  }
  for (const k of ['highlight', 'autoscroll', 'clean']) {
    $(k).addEventListener('change', (e) => { settings[k] = e.target.checked; save(true); });
  }
  $('replacements').addEventListener('input', (e) => { settings.replacements = e.target.value; save(); });
  $('sleep').addEventListener('change', async (e) => {
    state = (await send({ type: 'sleep', minutes: +e.target.value })) || state;
    renderState();
  });
  $('openShortcuts').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'state') {
      const prevLoc = state.locale;
      state = msg.state;
      renderState();
      if (settings.locale === 'auto' && state.locale !== prevLoc) { renderLocales(); renderVoices(); }
    }
  });
  document.addEventListener('pointerup', () => { dragging = false; });
}

async function renderShortcuts() {
  try {
    const cmds = await chrome.commands.getAll();
    const box = $('shortcuts');
    box.replaceChildren();
    for (const c of cmds) {
      if (!c.description) continue;
      const line = document.createElement('div');
      line.textContent = `${c.shortcut || '(sem atalho)'} — ${c.description}`;
      box.append(line);
    }
  } catch (e) { /* ignora */ }
}

// ---------- Início ----------
(async function init() {
  buildStatic();
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  [settings, voices] = await Promise.all([loadSettings(), loadVoices()]);
  state = (await send({ type: 'getState' })) || state;
  detectedLocale = await detectActiveLocale();
  bind();
  renderControls();
  renderLocales();
  renderVoices();
  renderState();
  renderShortcuts();
})();
