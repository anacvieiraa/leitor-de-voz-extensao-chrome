// Service worker: controla a fala (chrome.tts) em segundo plano.
// A leitura continua ao trocar de aba, fechar o popup ou minimizar a janela.
import {
  loadSettings, getVoices, normLocale, baseLang, pickVoice, detectLocale, SAMPLES
} from './common.js';

const HL_CSS = '::highlight(tts-reader-hl){background-color:#ffd54a;color:#000;}';

let settings = null;
let voicesCache = [];
let session = null;       // { tabId, title, raw:[{t,p}], chunks:[], index, autoLocale, startedAt }
let status = 'idle';      // idle | loading | playing | paused
let errorMsg = '';
let sleepAt = 0;
let gen = 0;              // "geração" da fala: eventos de falas antigas são ignorados
let queuedIdx = -1;       // último trecho já enviado à fila do TTS
let startSeq = 0;
let keepAliveId = null;
let rules = [];

// ---------- Estado persistido (o service worker pode ser suspenso) ----------
async function persist(full = false) {
  try {
    const o = {
      sleepAt,
      meta: session ? { tabId: session.tabId, title: session.title, index: session.index, autoLocale: session.autoLocale, status } : null
    };
    if (full) o.raw = session ? session.raw : null;
    await chrome.storage.session.set(o);
    if (!session) await chrome.storage.session.remove(['meta', 'raw']);
  } catch (e) { /* ignora */ }
}

async function restore() {
  try {
    settings = await loadSettings();
    rebuildRules();
    const d = await chrome.storage.session.get(['meta', 'raw', 'sleepAt']);
    sleepAt = d.sleepAt || 0;
    if (d.meta && d.raw) {
      session = { ...d.meta, raw: d.raw, startedAt: 0 };
      rebuildChunks();
      if (d.meta.status === 'playing') chrome.tts.stop(); // a cadeia de eventos se perdeu
      status = 'paused'; // retoma de onde parou ao apertar ▶
    }
    voicesCache = await getVoices();
    updateBadge();
  } catch (e) {
    settings = settings || await loadSettings();
  }
}
const ready = restore();

// ---------- Texto ----------
function rebuildRules() {
  rules = [];
  for (const line of (settings.replacements || '').split('\n')) {
    const i = line.indexOf('=');
    if (i < 1) continue;
    const from = line.slice(0, i).trim();
    const to = line.slice(i + 1).trim();
    if (!from) continue;
    try {
      const esc = from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      rules.push([new RegExp(`(?<![\\p{L}\\p{N}])${esc}(?![\\p{L}\\p{N}])`, 'giu'), to]);
    } catch (e) { /* regra inválida */ }
  }
}

function cleanText(s) {
  let t = s;
  if (settings.clean) {
    t = t
      .replace(/https?:\/\/\S+|www\.\S+/gi, ' link ')
      .replace(/\[\s*(?:\d{1,3}|[a-z]|nota\s*\d+)\s*\]/gi, ' ')
      .replace(/[​-‍﻿]/g, '')
      .replace(/\p{Extended_Pictographic}/gu, ' ');
  }
  for (const [re, to] of rules) t = t.replace(re, to);
  t = t.replace(/\s+/g, ' ');
  if (settings.clean) t = t.replace(/\s+([.,;:!?…])/g, '$1');
  t = t.trim();
  return /[\p{L}\p{N}]/u.test(t) ? t : '';
}

function rebuildChunks() {
  if (!session) return;
  session.chunks = session.raw.map((r) => cleanText(r.t));
}

const nextIdx = (i) => {
  if (!session) return -1;
  for (let k = Math.max(0, i); k < session.chunks.length; k++) if (session.chunks[k]) return k;
  return -1;
};

function nextParaIdx() {
  for (let i = session.index + 1; i < session.raw.length; i++) if (session.raw[i].p && session.chunks[i]) return i;
  return -1;
}

function prevParaIdx() {
  let i = session.index;
  while (i > 0 && !session.raw[i].p) i--;
  if (i < session.index) return nextIdx(i);
  let j = i - 1;
  while (j > 0 && !session.raw[j].p) j--;
  return nextIdx(Math.max(j, 0));
}

// ---------- Voz ----------
function effectiveLocale() {
  if (settings.locale !== 'auto') return settings.locale;
  return (session && session.autoLocale) || normLocale(navigator.language);
}

function buildOpts(locale) {
  const v = pickVoice(voicesCache, locale, settings.voices);
  const o = { rate: settings.rate, pitch: settings.pitch, volume: settings.volume, lang: locale };
  if (v) {
    o.voiceName = v.voiceName;
    if (v.extensionId) o.extensionId = v.extensionId;
  }
  return o;
}

function queueUtterance(i, g, enqueue) {
  chrome.tts.speak(session.chunks[i], {
    ...buildOpts(effectiveLocale()),
    enqueue,
    onEvent: (ev) => onTts(ev, i, g)
  });
}

function onTts(ev, i, g) {
  if (g !== gen || !session) return;
  switch (ev.type) {
    case 'start': {
      session.index = i;
      persist();
      broadcast();
      highlightCurrent();
      const n = nextIdx(i + 1);
      if (n >= 0 && queuedIdx < n) { queuedIdx = n; queueUtterance(n, g, true); } // pré-enfileira: sem pausas
      break;
    }
    case 'end': {
      const n = nextIdx(i + 1);
      if (n < 0) { finish(); break; }
      if (queuedIdx < n) { queuedIdx = n; queueUtterance(n, g, false); }
      break;
    }
    case 'error':
      fail(`Erro de voz: ${ev.errorMessage || 'desconhecido'}. Se a voz for online ("Google…"), verifique a internet ou escolha uma voz local.`);
      break;
    default:
  }
}

function speakFrom(i) {
  if (!session) return;
  const first = nextIdx(i);
  gen++;
  const g = gen;
  queuedIdx = -1;
  chrome.tts.stop();
  if (first < 0) { finish(); return; }
  session.index = first;
  status = 'playing';
  errorMsg = '';
  startKeepAlive();
  queuedIdx = first;
  queueUtterance(first, g, false);
  persist();
  broadcast();
}

// ---------- Controles ----------
function pauseReading() {
  if (status !== 'playing') return;
  gen++;
  chrome.tts.stop();
  status = 'paused';
  stopKeepAlive();
  persist();
  broadcast();
}

function resumeReading() {
  if (status !== 'paused' || !session) return;
  speakFrom(session.index);
}

function clearHighlightOnTab() {
  if (session) chrome.tabs.sendMessage(session.tabId, { type: 'clear' }).catch(() => {});
}

function hardStop(keepSleep = true) {
  startSeq++;
  gen++;
  chrome.tts.stop();
  clearHighlightOnTab();
  session = null;
  status = 'idle';
  stopKeepAlive();
  if (!keepSleep) { chrome.alarms.clear('sleep'); sleepAt = 0; }
}

function stopReading() {
  hardStop(false);
  persist();
  broadcast();
}

function finish() {
  hardStop(false);
  persist();
  broadcast();
}

function fail(msg) {
  hardStop(true);
  errorMsg = msg;
  persist();
  broadcast();
}

function highlightCurrent() {
  if (!session) return;
  const msg = settings.highlight
    ? { type: 'highlight', index: session.index, scroll: !!settings.autoscroll }
    : { type: 'clear' };
  chrome.tabs.sendMessage(session.tabId, msg).catch(() => {});
}

async function startReading({ tabId, mode = 'auto' }) {
  hardStop(true);
  const seq = startSeq;
  errorMsg = '';
  status = 'loading';
  broadcast();

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    await chrome.scripting.insertCSS({ target: { tabId }, css: HL_CSS });
  } catch (e) {
    if (seq === startSeq) fail('Esta página não permite extensões (páginas internas do Chrome, Chrome Web Store, visualizador de PDF…). Tente em outra aba.');
    return;
  }
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { type: 'extract', mode });
  } catch (e) {
    if (seq === startSeq) fail('Não consegui ler o conteúdo desta página. Recarregue a aba e tente novamente.');
    return;
  }
  if (seq !== startSeq) return;
  if (res && res.error === 'no-selection') return fail('Selecione um trecho de texto na página primeiro.');
  if (!res || !res.segments || !res.segments.length) return fail('Não encontrei texto legível nesta página.');

  voicesCache = await getVoices();
  const sample = res.segments.slice(0, 40).map((s) => s.t).join(' ').slice(0, 1500);
  const autoLocale = await detectLocale(sample, res.lang, voicesCache);
  if (seq !== startSeq) return;

  session = { tabId, title: res.title || '', raw: res.segments, index: res.startIndex || 0, autoLocale, startedAt: Date.now() };
  rebuildChunks();
  await persist(true);
  speakFrom(session.index);
}

async function previewVoice(locale) {
  if (status === 'playing' || status === 'loading') return;
  voicesCache = await getVoices();
  const loc = settings.locale !== 'auto' ? settings.locale : (locale || normLocale(navigator.language));
  gen++;
  chrome.tts.stop();
  chrome.tts.speak(SAMPLES[baseLang(loc)] || SAMPLES.en, buildOpts(loc));
}

async function setSleep(minutes) {
  await chrome.alarms.clear('sleep');
  if (minutes > 0) {
    sleepAt = Date.now() + minutes * 60000;
    await chrome.alarms.create('sleep', { delayInMinutes: minutes });
  } else {
    sleepAt = 0;
  }
  await persist();
  broadcast();
}

// ---------- Estado -> popup / ícone ----------
function publicState() {
  const total = session ? session.chunks.length : 0;
  let remChars = 0;
  if (session) for (let i = session.index; i < total; i++) remChars += session.chunks[i].length;
  const v = pickVoice(voicesCache, effectiveLocale(), settings.voices);
  return {
    status,
    index: session ? session.index : 0,
    total,
    title: session ? session.title : '',
    tabId: session ? session.tabId : null,
    locale: session ? effectiveLocale() : null,
    voiceName: v ? v.voiceName : '',
    remainingSec: Math.round(remChars / (15 * (settings.rate || 1))), // ~15 caracteres/s em 1×
    sleepAt: sleepAt > Date.now() ? sleepAt : 0,
    error: errorMsg
  };
}

function broadcast() {
  updateBadge();
  chrome.runtime.sendMessage({ type: 'state', state: publicState() }).catch(() => {});
}

function updateBadge() {
  const map = { playing: ['▶', '#16a34a', 'Lendo…'], paused: ['II', '#d97706', 'Pausado'], loading: ['…', '#6b7280', 'Carregando…'] };
  const m = map[status];
  chrome.action.setBadgeText({ text: m ? m[0] : '' });
  if (m) chrome.action.setBadgeBackgroundColor({ color: m[1] });
  chrome.action.setTitle({ title: `Leitor de Voz${m ? ' — ' + m[2] : ''}` });
}

function startKeepAlive() {
  stopKeepAlive();
  keepAliveId = setInterval(() => { chrome.runtime.getPlatformInfo(() => {}); }, 20000);
}
function stopKeepAlive() {
  if (keepAliveId) clearInterval(keepAliveId);
  keepAliveId = null;
}

// ---------- Mensagens ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type || msg.type === 'state') return false;
  (async () => {
    await ready;
    switch (msg.type) {
      case 'getState': break;
      case 'play': await startReading({ tabId: msg.tabId, mode: msg.mode }); break;
      case 'pause': pauseReading(); break;
      case 'resume': resumeReading(); break;
      case 'stop': stopReading(); break;
      case 'next': if (session) { const n = nextParaIdx(); if (n >= 0) speakFrom(n); else finish(); } break;
      case 'prev': if (session) speakFrom(prevParaIdx()); break;
      case 'seek': if (session) speakFrom(msg.index); break;
      case 'preview': await previewVoice(msg.locale); break;
      case 'sleep': await setSleep(msg.minutes); break;
      case 'seekFromPage':
        if (session && sender.tab && sender.tab.id === session.tabId) speakFrom(msg.index);
        break;
      default:
    }
    return publicState();
  })().then(sendResponse).catch((e) => sendResponse({ error: String(e) }));
  return true;
});

// ---------- Atalhos de teclado ----------
chrome.commands.onCommand.addListener(async (cmd, tab) => {
  await ready;
  switch (cmd) {
    case 'toggle-read': {
      if (status === 'playing') pauseReading();
      else if (status === 'paused') resumeReading();
      else {
        const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
        if (t) startReading({ tabId: t.id, mode: 'auto' });
      }
      break;
    }
    case 'stop-read': stopReading(); break;
    case 'next-paragraph': if (session) { const n = nextParaIdx(); if (n >= 0) speakFrom(n); else finish(); } break;
    case 'prev-paragraph': if (session) speakFrom(prevParaIdx()); break;
    default:
  }
});

// ---------- Menu de contexto ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'read-selection', title: 'Ler seleção em voz alta', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'read-page', title: 'Ler esta página em voz alta', contexts: ['page'] });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  await ready;
  if (!tab) return;
  startReading({ tabId: tab.id, mode: info.menuItemId === 'read-selection' ? 'selection' : 'page' });
});

// ---------- Ciclo de vida / configurações ----------
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sleep') return;
  await ready;
  sleepAt = 0;
  if (status !== 'idle') stopReading(); else { persist(); broadcast(); }
});

chrome.tabs.onRemoved.addListener(async (id) => {
  await ready;
  if (session && id === session.tabId) stopReading();
});

chrome.tabs.onUpdated.addListener(async (id, info) => {
  if (info.status !== 'loading') return;
  await ready;
  // a página foi recarregada ou navegou: encerra a leitura dela
  if (session && id === session.tabId && Date.now() - session.startedAt > 3000) stopReading();
});

chrome.storage.onChanged.addListener(async (_changes, area) => {
  if (area !== 'sync') return;
  await ready;
  const old = settings;
  settings = await loadSettings();
  rebuildRules();
  if (!session) return;
  const speechKeys = ['rate', 'pitch', 'volume', 'locale', 'voices'];
  const speechChanged = speechKeys.some((k) => JSON.stringify(old[k]) !== JSON.stringify(settings[k]));
  const textChanged = old.clean !== settings.clean || old.replacements !== settings.replacements;
  if (textChanged) rebuildChunks();
  if (status === 'playing' && (speechChanged || textChanged)) speakFrom(session.index);
  else if (speechChanged || textChanged) broadcast();
  if (old.highlight !== settings.highlight && status !== 'idle') highlightCurrent();
});
